package com.apps;

import com.apps.db.DBSQLConnection;

import java.sql.*;

import org.zkoss.zul.*;
import org.zkoss.zkex.zul.Jasperreport;

import net.sf.jasperreports.engine.JRResultSetDataSource;
import net.sf.jasperreports.engine.util.JRStyledTextParser;

import net.sf.jasperreports.engine.JRResultSetDataSource;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.design.JasperDesign;
import net.sf.jasperreports.engine.export.JRXlsAbstractExporterParameter;
import net.sf.jasperreports.engine.export.JRXlsExporter;
import net.sf.jasperreports.engine.export.JRXlsExporterParameter;
import net.sf.jasperreports.engine.xml.JRXmlLoader;
import net.sf.jasperreports.engine.JRDataSource;
import net.sf.jasperreports.engine.JRParameter;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;
import net.sf.jasperreports.engine.util.JRLoader;
import net.sf.jasperreports.view.JasperViewer;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.data.JRCsvDataSource;
import net.sf.jasperreports.engine.export.JRXlsExporter;
import net.sf.jasperreports.engine.export.JRXlsExporterParameter; 

import com.lowagie.text.pdf.codec.Base64.InputStream;
import com.lowagie.text.pdf.codec.Base64.OutputStream;
public class customer extends Window {
	String SQL;
	
	public void saveitem(String cid, String cname, String caddress) throws Exception {
		SQL="INSERT INTO CUSTOMER VALUES (?,?,?)";
		Connection Conn = new DBSQLConnection().openConnection();
		PreparedStatement prep = Conn.prepareStatement(SQL);
		prep.setString(1, cid);
		prep.setString(2, cname);
		prep.setString(3, caddress);
		prep.executeUpdate();
		Conn.close();
		
		Messagebox.show("Data has been saved successfully..","Data Saved",Messagebox.OK,Messagebox.INFORMATION);
		
		viewlist();
		
	}
	
	public void viewlist() throws Exception {
		Listbox lb=(Listbox)this.getFellow("lstData");
		lb.getItems().clear();
		
		SQL="SELECT * FROM CUSTOMER";
		Connection Conn = new DBSQLConnection().openConnection();
		Statement st = Conn.createStatement();
		ResultSet rs = st.executeQuery(SQL);
		
		while (rs.next()){
			Listitem li = new Listitem();
			li.setValue(rs.getString("idcust"));
			li.appendChild(new Listcell(rs.getString("idcust")));
			li.appendChild(new Listcell(rs.getString("namecust")));
			li.appendChild(new Listcell(rs.getString("address")));
			lb.appendChild(li);
		}
		rs.close();
		st.close();
		Conn.close();
	}
	
	public void rptcustomer() throws Exception {
		SQL="SELECT * FROM CUSTOMER";
		Connection Conn = new DBSQLConnection().openConnection();
		Statement st = Conn.createStatement();
		ResultSet rs = st.executeQuery("SELECT * FROM CUSTOMER");
		
		Jasperreport rpt =(Jasperreport)this.getFellow("rpt");
		
		rpt.setDatasource(new JRResultSetDataSource(rs));
		rpt.setSrc("content/rpt/rptcustomer.jasper");
		rpt.setType("pdf");
		

	}
	
}
